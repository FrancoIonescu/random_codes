.model small 

exit_dos MACRO
	mov AX, 4c00h
	int 21h
ENDM

mAdd2 MACRO op1, op2, sum 
	local while_none
	mov cx, 3
	while_none: 
	loop while_none 
	
	mov AX, op1 
	add AX, op2  
	mov sum, AX
ENDM

.stack 10h

.data
	A dw 9 
	B dw -3 
	C dw 26
	S dw ?
.code 
start: 
	mov AX, @data
	mov DS, AX
	
	mAdd2 A, B, S
	mAdd2 S, C, S
	
	exit_dos
end start 