.model large

.stack 10h 

exit_dos MACRO 
	mov AX, 4c00h
	int 21h 
ENDM

MyDataSrc SEGMENT
	src db 'ASM x86 on 16 bits$' 
	dimSrc dw $-src
MyDataSrc ENDS

MyDataDst SEGMENT
	dst db '111111111111111111$'
	dimDst dw $-dst
MyDataDst ENDS 

MainProg SEGMENT
; main: (gcc), _start: (ld) 
ASSUME CS: MainProg, DS: MyDataSrc, ES: MyDataDst
start:  
	mov AX, SEG src 
	mov DS, AX
	
	mov AX, SEG dst 
    mov ES, AX 
	
	cld

	mov CX, dimSrc 
	rep movsb
	;while_label:
	;	movsb
	;loop while_label

	exit_dos
MainProg ENDS 
end start 