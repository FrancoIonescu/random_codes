; The addition of items within array
.model large

MyData SEGMENT
	sum1 dw ?
	tab1 dw 2, 7, 15, 20
	n1 dw 4
	sum2 dw ?
	tab2 dw 2, -3, 16, 32, 64
	n2 dw $- tab2
MyData ENDS
 
MyStack SEGMENT
	dw 16 dup(3)
	mylablestck label word
MyStack ENDS

MainCode SEGMENT
ASSUME CS:MainCode, DS:MyData, SS:MyStack

start:
	 ;init DS reg
	 mov AX, seg MyData
	 mov DS, AX

	 ;init stack
	 mov AX, seg MyStack
	 mov SS, AX
	 mov SP, offset mylablestck

	;void addv(int* suma, short int n, short int* tab);
	mov AX, seg tab1
	push AX 
	mov AX, offset tab1 
	push AX
	
	mov AX, n1 
	push AX

	mov AX, seg sum1
	push AX 
	mov AX, offset sum1
	push AX
	
	call FAR PTR addv
	
	
	mov AX, seg tab2 
	push AX 
	mov AX, offset tab2  
	push AX
	
	mov AX, n2
    shr AX, 1	; n2 = 10 -> 0000_0101 -> shr 
	push AX

	mov AX, seg sum2
	push AX 
	mov AX, offset sum2 
	push AX
	
	call FAR PTR addv
 
 
	mov AX, 4C00h
	int 21h
MainCode ENDS

ProcsCode SEGMENT
ASSUME CS:ProcsCode

addv PROC FAR
	 push BP
	 mov BP, SP
	 ; BP_val, IP_r, CS_r, offset sum, seg sum, n, off tab, seg tab
	 ; |.   |
	 ;[BP]. [BP+2]
	 
	 
	 mov CX, SS:[BP+10] ; mov CX, DS:[000Ah]
	 
	 mov DX, [BP+14]
	 mov DS, DX 
	 
	 mov BX, [BP+12]
	 
	 mov SI, 0
	 
	 xor AX, AX
	 while_label:  
		add AX, DS:[BX][SI]   ; sum(AX) += tab[i] ; [SI*sizeof(short int)]
		add SI, 2		      ; i += 1 * sizeof(short int)
	 loop while_label

	 mov DX, [BP+8]
	 mov DS, DX 
	 mov BX, [BP+6]
	 mov DS:[BX], AX

	 pop BP

     retf 10
addv ENDP

ProcsCode ENDS
end start