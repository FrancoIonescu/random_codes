package eu.deic.ism;

import io.javalin.Javalin;
import io.javalin.http.staticfiles.Location;
import io.javalin.http.UploadedFile;

import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.AMQP;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class App {

    private static final Logger log = LoggerFactory.getLogger(App.class);
    private static final String EXCHANGE_NAME = "image_topic";

    public static void main(String[] args) {

        Javalin app = Javalin.create(config -> {
            // Servește fișiere statice din /app/staticHTML (în container)
            config.staticFiles.add("/app/staticHTML", Location.EXTERNAL);
        }).start(8080);

        log.info("C01 WebApp a pornit pe portul 8080...");

        app.post("/upload", ctx -> {
            UploadedFile file = ctx.uploadedFile("picture");
            String aesKey = ctx.formParam("aesKey");
            String operation = ctx.formParam("operation");
            String mode = ctx.formParam("mode");

            // Validare fișier
            if (file == null || file.size() == 0) {
                ctx.status(400).json(Map.of(
                        "status", "error",
                        "message", "Nu ai selectat nicio poză"
                ));
                return;
            }

            // Validare cheie AES (exemplu: 16 caractere pentru AES-128)
            if (aesKey == null || aesKey.length() != 16) {
                ctx.status(400).json(Map.of(
                        "status", "error",
                        "message", "Cheia AES trebuie să aibă exact 16 caractere"
                ));
                return;
            }

            // Validare operație
            if (operation == null || (!operation.equals("encrypt") && !operation.equals("decrypt"))) {
                ctx.status(400).json(Map.of(
                        "status", "error",
                        "message", "Operația trebuie să fie 'encrypt' sau 'decrypt'"
                ));
                return;
            }

            // Validare mod (ex: ECB, CBC etc. – aici doar verificăm să nu fie null/vid)
            if (mode == null || mode.isBlank()) {
                ctx.status(400).json(Map.of(
                        "status", "error",
                        "message", "Modul de criptare nu poate fi gol"
                ));
                return;
            }

            // Validare tip fișier (opțional, dar util)
            String contentType = file.contentType();
            if (contentType == null || !contentType.equalsIgnoreCase("image/bmp")) {
                ctx.status(400).json(Map.of(
                        "status", "error",
                        "message", "Doar fișiere BMP sunt acceptate"
                ));
                return;
            }

            byte[] imageBytes;
            try {
                imageBytes = file.content().readAllBytes();
            } catch (Exception e) {
                log.error("Eroare la citirea fișierului uploadat", e);
                ctx.status(500).json(Map.of(
                        "status", "error",
                        "message", "Eroare la citirea fișierului"
                ));
                return;
            }

            try {
                sendToRabbit(imageBytes, aesKey, operation, mode, file.filename());
                log.info("Mesaj trimis cu succes către RabbitMQ pentru fișierul {}", file.filename());

                ctx.status(200).json(Map.of(
                        "status", "success",
                        "message", "Poza a fost trimisă spre procesare",
                        "fileName", file.filename(),
                        "operation", operation,
                        "mode", mode
                ));
            } catch (Exception e) {
                log.error("Eroare la trimiterea către RabbitMQ", e);
                ctx.status(500).json(Map.of(
                        "status", "error",
                        "message", "Eroare la trimiterea către brokerul RabbitMQ"
                ));
            }
        });
    }

    private static void sendToRabbit(byte[] imageBytes,
                                     String aesKey,
                                     String operation,
                                     String mode,
                                     String fileName) throws Exception {

        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("c02-broker"); // numele containerului RabbitMQ din docker-compose
        factory.setUsername("guest");
        factory.setPassword("guest");

        try (Connection connection = factory.newConnection();
             Channel channel = connection.createChannel()) {

            log.info("Conexiune și canal RabbitMQ create");

            channel.exchangeDeclare(EXCHANGE_NAME, "topic", true);
            log.info("Exchange declarat: {}", EXCHANGE_NAME);

            Map<String, Object> headers = new HashMap<>();
            headers.put("aesKey", aesKey);
            headers.put("operation", operation);
            headers.put("mode", mode);
            headers.put("fileName", fileName);

            AMQP.BasicProperties props = new AMQP.BasicProperties.Builder()
                    .headers(headers)
                    .contentType("image/bmp")
                    .build();

            channel.basicPublish(EXCHANGE_NAME, "image.process", props, imageBytes);
            log.info("Mesaj publicat în exchange {} cu routing key {}", EXCHANGE_NAME, "image.process");
        }
    }
}
