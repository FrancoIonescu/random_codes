package eu.deic.ism;

import com.rabbitmq.client.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;

public class SubscriberApp {

    private static final Logger log = LoggerFactory.getLogger(SubscriberApp.class);
    private static final String EXCHANGE_NAME = "image_topic";

    public static void main(String[] args) throws Exception {

        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("c02-broker");
        factory.setUsername("guest");
        factory.setPassword("guest");

        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        channel.exchangeDeclare(EXCHANGE_NAME, "topic", true);
        String queueName = channel.queueDeclare().getQueue();
        channel.queueBind(queueName, EXCHANGE_NAME, "image.process");

        log.info("C03 Processor este pornit și ascultă mesaje din RabbitMQ...");

        DeliverCallback deliverCallback = (consumerTag, delivery) -> {
            try {
                handleMessage(delivery);
            } catch (Exception e) {
                log.error("Eroare la procesarea mesajului!", e);
            }
        };

        channel.basicConsume(queueName, true, deliverCallback, consumerTag -> {});
    }

    private static void handleMessage(Delivery delivery) throws Exception {
        byte[] imageBytes = delivery.getBody();
        Map<String, Object> headers = delivery.getProperties().getHeaders();

        String fileName = getHeader(headers, "fileName");
        String operation = getHeader(headers, "operation");
        String aesKey = getHeader(headers, "aesKey");

        log.info("Mesaj primit: {} | operație: {}", fileName, operation);

        // 1. Salvăm fișierul primit
        String fullPath = "/app/photos/" + fileName;
        saveFile(fullPath, imageBytes);

        // 2. Lansăm procesarea MPI
        runMPI(fullPath, aesKey);
    }

    private static String getHeader(Map<String, Object> headers, String key) {
        Object value = headers.get(key);
        return value != null ? value.toString() : "";
    }

    private static void saveFile(String path, byte[] data) {
        try (FileOutputStream fos = new FileOutputStream(path)) {
            fos.write(data);
            log.info("Fișier salvat în {}", path);
        } catch (IOException e) {
            log.error("Eroare la salvarea fișierului {}", path, e);
        }
    }

    private static void runMPI(String filePath, String aesKey) {
        try {
            log.info("Se lansează MPI pentru {}", filePath);

            ProcessBuilder pb = new ProcessBuilder(
                    "mpirun",
                    "-np", "2",
                    "--host", "c03_processor,c04_worker",
                    "/usr/local/bin/mpi_processor",
                    filePath,
                    aesKey
            );

            pb.inheritIO(); // logurile C++ apar în docker logs

            Process p = pb.start();
            int exitCode = p.waitFor();

            if (exitCode == 0) {
                log.info("MPI finalizat cu succes pentru {}", filePath);
            } else {
                log.error("MPI a returnat codul {}", exitCode);
            }

        } catch (Exception e) {
            log.error("Eroare la execuția MPI!", e);
        }
    }
}
