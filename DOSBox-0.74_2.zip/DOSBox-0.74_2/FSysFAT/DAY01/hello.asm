.model small ;ask for 64k
.stack 10h ;ask for a 16B stack
.data
	vb1 DB 100
	vb2 DB 200
	result DW ?
	msg DB 'Hello Assembly$'
	values DB 10,20,30,40
	values_new DB ?,?,?,?,?
	many_values DB 10 dup (100)
.code
	MOV AX,@data
	MOV DS,AX
	
	XOR AX, AX ; same as MOV AX,0
	MOV AL,vb1
	add AL,vb2
	adc AH, 0
	MOV result, AX
	
	;copy the result on stack
	PUSH AX
	PUSH AX
	
	;print msg
	;save values of AX on stack
	PUSH AX
	MOV AH, 09h
	MOV DX, 4 ;offset  msg 
	int 21h
	
	;recover AX
	POP AX
	

	
	MOV AX, 4C00h
	int 21h
end