.model small

.stack 16

.data ; .bss in linux

	x DW -2
	y DW 9
	s2 DW ?
	
	a DW -7
	b DW 9
	max DW ?
	
	n DW 4
	vector dw 23, -13, 54, 64
	sum dw ?

.code ; .text in linux

start:
	mov AX, @data
	mov DS, AX
	
	mov AX, x 
	mov AX, y
	mov s2, AX
	
	; if-then-else
	mov AX, a
	cmp AX, b
	jle false
	true:
		mov max, AX
		jmp final
	false: 
		mov AX, b
		mov max, AX
	final:
	nop
	
	xor CX, CX
	mov CX, n 
	mov BX, offset vector
	xor AX, AX 
	xor SI, SI  
	for_while:
		add AX, DS:[BX][SI]
		inc SI
		inc SI
	loop for_while 
	mov sum, AX 
	
	mov AX, 4c00h
	int 21h
end start