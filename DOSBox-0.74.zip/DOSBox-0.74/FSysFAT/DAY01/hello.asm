.model small ; ask for 64k
.stack 10h ; ask for a 16bytes stack
.data
    vb1 DB 100
	vb2 DB 200
	result DW ?
	msg DB 'Hello Assembly$'
	values 10,20,30,40
	values ?, ?, ?, ?, ?
	many_values 10 dup (100)
.code
	MOV AX,@data
	MOV DS,AX
	
	XOR AX, AX ; same as MOV AX, 0
	MOV AL, vb1
	ADD AL, vb2
	ADC AH, 0
	MOV result, AX
	
    ;alternative
    ;MOV AH, 4Ch
    ;MOV AL, 00h
   
    ;copy the result in stack
    PUSH AX
	PUSH AX
	
	;print message
	;save value of AX on stack
	PUSH AX
	MOV AH, 09h
	MOV DX, 4 ;offset msg
	int 21h
	
	;recover AX
	POP AX
   
	MOV AX, 4C00h
	int 21h
end
	