mkdir -p ~/jcse/jctools
mkdir -p ~/jcse/jcsimu

export JAVA_HOME=/opt/software/java/jdks/jdk-25.0.1
export PATH=.:$JAVA_HOME/bin:$PATH
export JC_HOME_TOOLS=~/jcse/jctools
export JC_HOME_SIMULATOR=~/jcse/jcsimu
export LD_LIBRARY_PATH=$JC_HOME_SIMULATOR/runtime/bin:$JC_HOME_SIMULATOR/client/COMService

# terminal 1 - Server - JC Simulator:

# The following steps configure Linux Ubuntu and Linux Oracle to run 32-bit applications on x86 CPU:
# Linux Ubuntu:
sudo dpkg --add-architecture i386
sudo apt update
sudo apt install libc6-i386
# RHEL/Amazon/Oracle Linux:
sudo dnf update
sudo dnf install glibc.i686
cd $JC_HOME_SIMULATOR
java -cp . -jar $JC_HOME_SIMULATOR/tools/Configurator.jar -binary $JC_HOME_SIMULATOR/runtime/bin/jcsl -SCP-keyset 10 1111111111111111111111111111111111111111111111111111111111111111 2222222222222222222222222222222222222222222222222222222222222222 3333333333333333333333333333333333333333333333333333333333333333 -global-pin 01020304050f 03
./runtime/bin/jcsl
# terminal 2 - Client - Java Off-card/Host App:
cd $JC_HOME_SIMULATOR/samples

cd Wallet
./build.sh
./run.sh

# be sure you have in $JC_HOME_SIMULATOR/samples/client.config.properties the following:
#
# Copyright (c) 1998, 2025, Oracle and/or its affiliates. All rights reserved.
#
# A000000151000000_scp03enc_< your kvn >=< your enc key here >
# A000000151000000_scp03mac_< your kvn >=< your mac key here >
# A000000151000000_scp03dek_< your kvn >=< your dek key here >

A000000151000000_scp03enc_10=1111111111111111111111111111111111111111111111111111111111111111 
A000000151000000_scp03mac_10=2222222222222222222222222222222222222222222222222222222222222222 
A000000151000000_scp03dek_10=3333333333333333333333333333333333333333333333333333333333333333