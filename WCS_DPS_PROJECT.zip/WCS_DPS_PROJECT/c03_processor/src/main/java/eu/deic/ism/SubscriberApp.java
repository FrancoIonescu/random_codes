package eu.deic.ism;

import com.rabbitmq.client.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;

public class SubscriberApp {
    private final static String EXCHANGE_NAME = "image_topic";

    public static void main(String[] args) throws Exception {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("c02-broker");
        factory.setUsername("guest");
        factory.setPassword("guest");

        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        channel.exchangeDeclare(EXCHANGE_NAME, "topic", true);
        String queueName = channel.queueDeclare().getQueue();
        channel.queueBind(queueName, EXCHANGE_NAME, "image.process");

        System.out.println(" [*] C03 asteapta poze. Pentru iesire apasati CTRL+C");

        DeliverCallback deliverCallback = (consumerTag, delivery) -> {
            byte[] imageBytes = delivery.getBody();
            Map<String, Object> headers = delivery.getProperties().getHeaders();

            String fileName = headers.get("fileName").toString();
            String operation = headers.get("operation").toString();
			String aesKey = headers.get("aesKey").toString();

            System.out.println(" [x] Am primit: " + fileName + " | Operatie: " + operation);

            // 1. Salvăm poza pe disk
            String fullPath = "/app/photos/" + fileName;
            try (FileOutputStream fos = new FileOutputStream(fullPath)) {
                fos.write(imageBytes);
                System.out.println(" [x] Fisier salvat local in: " + fullPath);
            } catch (IOException e) {
                e.printStackTrace();
            }

            // 2. Lansăm MPI folosind ProcessBuilder (pentru a vedea logurile C++)
            try {
                System.out.println(" [!] Se lanseaza procesul MPI pentru: " + fileName);
                
                ProcessBuilder pb = new ProcessBuilder(
					"mpirun", "--allow-run-as-root", 
					"--hostfile", "/app/hosts", 
					"-np", "2", 
					"/usr/local/bin/mpi_processor", fullPath, aesKey
				);
                
                // Această linie "leagă" consola C++ de consola Docker log
                pb.inheritIO(); 
                
                Process p = pb.start();
                int exitCode = p.waitFor();
                
                System.out.println(" [!] Procesul MPI s-a finalizat cu codul: " + exitCode);
            } catch (Exception e) {
                System.err.println(" [!] Eroare la executia MPI!");
                e.printStackTrace();
            }
        };

        channel.basicConsume(queueName, true, deliverCallback, consumerTag -> { });
    }
}