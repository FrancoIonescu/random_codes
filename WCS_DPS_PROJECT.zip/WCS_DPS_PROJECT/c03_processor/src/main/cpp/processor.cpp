#include <mpi.h>
#include <omp.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <cstdint>
#include <unistd.h>

using namespace std;

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (argc < 3) {
        if (rank == 0) cout << "Eroare: Lipsesc argumentele!" << endl;
        MPI_Finalize();
        return 1;
    }

    string filePath = argv[1];
    string userKey = argv[2];
    vector<unsigned char> buffer;
    uint32_t dataOffset = 0;
    uint32_t totalPixelsSize = 0;

    if (rank == 0) {
        // MASTER: Citeste fisierul
        ifstream file(filePath, ios::binary);
        if (!file) {
            cout << "Eroare deschidere fisier!" << endl;
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        buffer.assign((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
        file.close();

        dataOffset = *(uint32_t*)&buffer[10];
        totalPixelsSize = buffer.size() - dataOffset;

        cout << " [Master MPI] Distribui " << totalPixelsSize << " bytes la " << size << " noduri." << endl;
    }

    // Trimitem dimensiunea si offset-ul tuturor nodurilor
    MPI_Bcast(&dataOffset, 1, MPI_UINT32_T, 0, MPI_COMM_WORLD);
    MPI_Bcast(&totalPixelsSize, 1, MPI_UINT32_T, 0, MPI_COMM_WORLD);

    // Calculam bucata pentru fiecare (simplificat: 2 noduri)
    uint32_t chunkSize = totalPixelsSize / size;
    vector<unsigned char> localData(chunkSize);

    if (rank == 0) {
        // Master pastreaza prima bucata si trimite restul
        for (int i = 1; i < size; i++) {
            MPI_Send(&buffer[dataOffset + i * chunkSize], chunkSize, MPI_UNSIGNED_CHAR, i, 0, MPI_COMM_WORLD);
        }
        // Copiaza bucata proprie
        for (uint32_t i = 0; i < chunkSize; i++) localData[i] = buffer[dataOffset + i];
    } else {
        // Worker-ul primeste datele
        MPI_Recv(localData.data(), chunkSize, MPI_UNSIGNED_CHAR, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }

    // PROCESARE: Fiecare nod cripteaza bucata sa (OpenMP inclus aici)
    // Folosim un multiplicator pentru a "împrăștia" cheia mai tare
	#pragma omp parallel for
	for (uint32_t i = 0; i < chunkSize; i++) {
		// Luăm un caracter din cheie în funcție de poziția absolută în fișier
		// Adăugăm un "salt" (i * 31) pentru a rupe pattern-ul repetitiv
		unsigned char keyChar = userKey[(i + rank * chunkSize) % userKey.length()];
		
		// Aplicăm XOR
		localData[i] = localData[i] ^ keyChar;
		
		// OPȚIONAL: Mai facem o rotație de biți sau o adunare modulară pentru haos total
		localData[i] = (localData[i] + keyChar) % 256; 
	}

    // COLECTARE: Trimitem inapoi la Master
    if (rank == 0) {
        // Master pune bucata sa inapoi in buffer
        for (uint32_t i = 0; i < chunkSize; i++) buffer[dataOffset + i] = localData[i];

        // Primeste de la ceilalti
        for (int i = 1; i < size; i++) {
            MPI_Recv(&buffer[dataOffset + i * chunkSize], chunkSize, MPI_UNSIGNED_CHAR, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        // Salvare finala
        string outPath = "/app/photos/distrib_processed_" + filePath.substr(filePath.find_last_of("/\\") + 1);
        ofstream outFile(outPath, ios::binary);
        outFile.write((char*)buffer.data(), buffer.size());
        outFile.close();
        cout << " [Master MPI] Succes! Imagine distribuita salvata in: " << outPath << endl;
    } else {
        // Worker trimite datele procesate inapoi
        MPI_Send(localData.data(), chunkSize, MPI_UNSIGNED_CHAR, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Finalize();
    return 0;
}