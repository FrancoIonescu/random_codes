// mvn clean compile exec:java -Dexec.mainClass="eu.deic.ism.App"

package eu.deic.ism;

import io.javalin.Javalin;
import io.javalin.http.staticfiles.Location;
import io.javalin.http.UploadedFile;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.AMQP;
import java.util.HashMap;
import java.util.Map;

public class App {
    private final static String EXCHANGE_NAME = "image_topic";

    public static void main(String[] args) {
        
        Javalin app = Javalin.create(config -> {
            config.staticFiles.add("/app/staticHTML", Location.EXTERNAL);
        }).start(8080);

        System.out.println("C01 WebApp a pornit pe portul 8080...");

        app.post("/upload", ctx -> {
            UploadedFile file = ctx.uploadedFile("picture");
            String aesKey = ctx.formParam("aesKey");
            String operation = ctx.formParam("operation");
            String mode = ctx.formParam("mode");

            if (file != null) {
                byte[] imageBytes = file.content().readAllBytes();
                
                // --- LOGICA RABBITMQ ---
                try {
                    ConnectionFactory factory = new ConnectionFactory();
                    factory.setHost("c02-broker"); 
                    factory.setUsername("guest");
                    factory.setPassword("guest");

                    // Resursele se declara DOAR aici in paranteze
                    try (Connection connection = factory.newConnection();
                         Channel channel = connection.createChannel()) {
                        
                        System.out.println("Step 1 & 2: Conexiune si Canal create!");

                        channel.exchangeDeclare(EXCHANGE_NAME, "topic", true);
                        System.out.println("Step 3: Exchange declarat: " + EXCHANGE_NAME);

                        Map<String, Object> headers = new HashMap<>();
                        headers.put("aesKey", aesKey);
                        headers.put("operation", operation);
                        headers.put("mode", mode);
                        headers.put("fileName", file.filename());

                        AMQP.BasicProperties props = new AMQP.BasicProperties.Builder()
                                .headers(headers)
                                .contentType("image/bmp")
                                .build();

                        channel.basicPublish(EXCHANGE_NAME, "image.process", props, imageBytes);
                        
                        System.out.println("Step 4: Mesaj trimis cu succes către RabbitMQ!");
                    } 
                } catch (Exception e) {
                    System.err.println("RABBITMQ Error");
                    e.printStackTrace();
                    ctx.status(500).result("Broker Error: " + e.getMessage());
                    return; // Oprim execuția pentru a nu trimite mesajul de succes de mai jos
                }

                ctx.html("<h3>Succes!</h3><p>Poza <b>" + file.filename() + 
                         "</b> a fost trimisa spre procesare.</p><a href='/index.html'>Inapoi</a>");
            } else {
                ctx.status(400).result("Eroare: Nu ai selectat nicio poza!");
            }
        });
    }
}